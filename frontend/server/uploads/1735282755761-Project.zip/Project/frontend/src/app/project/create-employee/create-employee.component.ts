import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-employee',
  standalone: false,
  
  templateUrl: './create-employee.component.html',
  styleUrl: './create-employee.component.css'
})
export class CreateEmployeeComponent {

  constructor(public http:HttpClient,public router:Router){}
  adminEmail:String="";
  empName:string="";
  empEmail:string="";
  empPassword:string="";
  empConfirmPassword:string="";
  empPhoneno:number=0;


  registerEmp(){
    debugger;
    this.adminEmail = localStorage.getItem('userEmail') || '';
    if (!this.empName || !this.empEmail || !this.empPassword || !this.empConfirmPassword) {
      alert('All fields are required!');
      return;
    }
    if (this.empPassword !== this.empConfirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    const userPayload = {
      adminEmail:this.adminEmail,
      empName: this.empName,
      empEmail: this.empEmail,
      empPassword: this.empPassword,
      empPhoneno: this.empPhoneno,
    };
    this.http.post<{message:String}>(
      'http://localhost:3000/user/createEmp',
      userPayload
    ).subscribe(
      (resultData) => {
        if(resultData){
          alert(resultData.message);
          this.router.navigate(["/employeeTable"]);
        }
        
        else{
          alert("failed");
        }
      },
      (error) => {
        console.error('Error:', error); 
        alert('An error occurred: ' + error.message);
      }
    );
  }
}
