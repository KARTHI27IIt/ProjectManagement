import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-create-project',
  standalone: false,
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent {
  adminEmail: string = '';
  project_name: string = "";
  project_desc: string = "";
  project_start: Date = new Date();
  project_end: Date = new Date();
  no_of_tasks: number = 0;
  project_id:String='';
  project_status:String="";
  
  
  constructor(
    public http: HttpClient,
    public router: Router,
    public authService: AuthService
  ) {}

  ngOnInit() {
    if (!this.authService.isLoggedIn()) {
      alert('You must be logged in to access the dashboard!');
      this.router.navigate(['/login']);
    } else {
      this.adminEmail = localStorage.getItem('userEmail') || '';
    }
  }


  createProject() {
    if (!this.project_name || !this.project_desc || !this.project_start || !this.project_end) {
      alert('All fields for the project are required!');
      return;
    }
  
    const projectDetails = {
      adminEmail: this.adminEmail,
      project_name: this.project_name,
      project_desc: this.project_desc,
      project_start: this.project_start,
      project_end: this.project_end,
      no_of_tasks: this.no_of_tasks,
      project_status:this.project_status
    };

    this.http.post<{ status: boolean, message: string ,project_id:String}>(
      'http://localhost:3000/user/createProject',
      projectDetails
    ).subscribe(
      (resultData) => {
        if (resultData.status) {
          alert(resultData.message);
          this.project_id=resultData.project_id;
          this.router.navigate(['/projectTable']); 
        } else {
          alert('Project creation failed');
        }
      },
      (error) => {
        console.error('Error:', error);
        alert('An error occurred: ' + error.message);
      }
    );
  }
  
}
