import { Component, inject, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  standalone:false,
  styleUrls: ['./project.component.css'],
})
export class ProjectComponent implements OnInit {
  adminDetails: any = {}
  adminEmail: string | null = '';
  private route = inject(ActivatedRoute);
  private authService: AuthService;
  private http: HttpClient;
  private router: Router;
  project:any;
  project_id:String="";
  tasks:any;

  constructor(
    authService: AuthService,
    http: HttpClient,
    router: Router
  ) {
    this.authService = authService;
    this.http = http;
    this.router = router;
  }

formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US'); 
}

  ngOnInit(): void {
    this.route.params.subscribe((params)=>{
      this.project_id = params["id"];
    });

    this.getSingleProject();
  /* this.adminEmail = localStorage.getItem('userEmail');
    if (!this.adminEmail) {
      console.error('Admin email not found');
      return;
    }

    this.authService.getAdminDetails(this.adminEmail).subscribe({
      next: (response) => {
        if (response.status) {
          this.adminDetails = response.adminDetails;
          console.log(this.adminDetails);
        } else {
          console.error('Error:', response.message);
        }
      },
      error: (error) => console.error('Error fetching admin details:', error),
    });*/
  }

  tasksIds:any;
  // GET PROJECT DETAILS
  
  getSingleProject(): void {
  const PROJECT_ID={
    project_id:this.project_id
  };
    this.http
      .post<{ status: boolean; project:any }>('http://localhost:3000/user/SingleProject',PROJECT_ID)
      .subscribe({
        next: (result) => {
          if (result.status) {
            this.project = result.project[0];
            this.tasksIds=this.project.tasks;
            console.log(this.project);
            console.log(this.tasksIds);
            this.getTasksDetails();
          } else {
            console.error('No projects found');
          }
        },
        error: (error) => console.error('Error fetching projects:', error),
      });
  }

  getTasksDetails():void{
    this.http
      .post<{ status: boolean; tasks:any,message:String }>('http://localhost:3000/user/getTasks',this.tasksIds)
      .subscribe({
        next: (result) => {
          if (result.status) {
            console.log(result.tasks);
            this.tasks=result.tasks;
          } else {
            console.error('No projects found');
          }
        },
        error: (error) => console.error('Error fetching projects:', error),
      });
  }



  CreateTasks(projectId:String){
    console.log(this.project.no_of_tasks);
    console.log(this.project.tasks.length);
    if(this.project.no_of_tasks>=this.project.tasks.length){
      this.router.navigate(['/createTasks', projectId]);
    }else{
      alert("Update the No of tasks field to add tasks")
    }
  }

  EditTask(task_id:String){
    console.log("Edit");
    this.router.navigate(["editTask",task_id]);
    
  }
  DeleteTask(task_id:String){
    const Task = {
      task_id:task_id,
    };
  
    console.log("DeleteEmployee",Task);
  
    this.http
      .delete<{ status: boolean; message: string }>('http://localhost:3000/user/DeleteTask', {
        body: Task
      })
      .subscribe({
        next: (result) => {
          if (result.status) {
            alert(result.message);  
            console.log("Task Deleted Successfull");
            window.location.reload();
          } else {
            console.error('No Task found');
          }
        },
        error: (error) => console.error('Error fetching Task:', error),
      });
  }
  EditProject(projectId: string ):void {
    console.log(projectId);
    this.router.navigate(['EditProject', projectId]);
}

}
