import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  standalone:false,
  styleUrls: ['./edit-employee.component.css'] 
})
export class EditEmployeeComponent implements OnInit {
  empName: string = '';
  empEmail: string = '';
  empPassword: string = '';
  empPhoneno: number = 0;
  employee_id: string = '';

  private route = inject(ActivatedRoute); 
  constructor(public http: HttpClient,public router:Router) {} 

  employee: any;

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.employee_id = params['id'];
    });
    this.getEmployee();
  }

  getEmployee() {
    const EMPLOYEE_ID = {
      employee_id: this.employee_id,
    };

    this.http
      .post<{ status: boolean; employee: any }>(
        'http://localhost:3000/user/SingleEmployee',
        EMPLOYEE_ID
      )
      .subscribe({
        next: (result) => {
          if (result.status) {
            this.employee = result.employee[0]; 
            console.log(this.employee);
          } else {
            console.error('No employee found');
          }
        },
        error: (error) => console.error('Error fetching employee:', error),
      });
  }

  EditEmployee(){
    const EmployeeDetails = {
      employee_id:this.employee_id,
      empName:this.employee.empName,
      empEmail:this.employee.empEmail,
      empPhoneno:this.employee.empPhoneno,
      empPassword:this.employee.empPassword
    };
    console.log("Updating employee Details:",EmployeeDetails);
    this.http.put<{ status: boolean, message: string ,employee:any}>(
      'http://localhost:3000/user/EditEmployee',
      EmployeeDetails
    ).subscribe(
      (resultData) => {
        if (resultData.status) {
          alert(resultData.message);
          console.log("Updated employee:",resultData.employee);
          this.router.navigate(["employeeTable"]);
        } else {
          alert('employee creation failed');
        }
      },
      (error) => {
        console.error('Error:', error);
        alert('An error occurred: ' + error.message);
      }
    );
  }
}
