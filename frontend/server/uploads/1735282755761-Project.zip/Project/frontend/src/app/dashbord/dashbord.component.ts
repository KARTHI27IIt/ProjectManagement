import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashbord',
  templateUrl: './dashbord.component.html',
  standalone:false,
  styleUrls: ['./dashbord.component.css'],
})
export class DashbordComponent implements OnInit {
  adminName: string = '';
  adminDetails: any;
  adminEmail: string | null = '';
  name: string = '';
  email: string = '';
  projectIds: any = [];
  employeeIds:any;
  projects: any = [];
  employees:any;
  tasks:any;
  taskIds:any;
  tasknumber: number = 0;

  constructor(
    private authService: AuthService,
    public router: Router,
    public http: HttpClient
  ) {}

  ngOnInit() {
    if (!this.authService.isLoggedIn()) {
      alert('You must be logged in to access the dashboard!');
      this.router.navigate(['/login']);
      return;
    }

    this.adminEmail = localStorage.getItem('userEmail') || '';
    console.log(this.adminEmail);

    if (!this.adminEmail) {
      console.error('Admin email not found');
      return;
    }

    this.authService.getAdminDetails(this.adminEmail).subscribe({
      next: (response) => {
        if (response.status) {
          this.adminDetails = response.adminDetails[0];
          console.log(this.adminDetails);
          this.getProjects(); // Fetch projects after admin details are retrieved
        } else {
          console.error('Error:', response.message);
        }
      },
      error: (error) => console.error('Error fetching admin details:', error),
    });
  }

  getProjects(): void {
    this.projectIds = this.adminDetails?.projects || [];
    if (!this.projectIds.length) {
      console.warn('No projects found for the admin');
      return;
    }

    this.http
      .post<{ status: boolean; projects: any[] }>(
        'http://localhost:3000/user/projects',
        { projectIds: this.projectIds }
      )
      .subscribe({
        next: (result) => {
          if (result.status) {
            this.projects = result.projects || [];
            this.calculateTaskNumber(); 
          } else {
            console.error('No projects found');
          }
        },
        error: (error) => console.error('Error fetching projects:', error),
      });
  }

  getemployees(): void {
    this.employeeIds = this.adminDetails[0]?.employees || [];
    if (!this.employeeIds.length) {
      console.warn('No employees found for the admin');
      return;
    }
    console.log("Employee Ids:",this.employeeIds);

    this.http
       .post<{ status: boolean; employees: any[];assignedTask:any }>('http://localhost:3000/user/employees', {
        employeeIds: this.employeeIds,
       })
       .subscribe({
         next: (result) => {
           if (result.status) {
             this.employees= result.employees || [];
             console.log("Employees",this.employees);
             this.taskIds =result.assignedTask;
             
           } else {
             console.error('No employees found');
           }
         },
         error: (error) => console.error('Error fetching employees:', error),
       });
  }



  calculateTaskNumber(): void {
    this.tasknumber = this.projects.reduce(
      (total: number, project: any) => total + (project.tasks?.length || 0),
      0
    );
    console.log('Total number of tasks:', this.tasknumber);
  }

  project(project_id:String){
    this.router.navigate(["project",project_id]);
  }
}
