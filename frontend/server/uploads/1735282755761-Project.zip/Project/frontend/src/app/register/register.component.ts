import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  standalone: false,
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  name: string = '';
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  phoneno: string = ''; // Changed to string for better validation
  loading: boolean = false; // For UX enhancements

  constructor(private http: HttpClient, private router: Router) {}

  register() {
    // Basic client-side validations
    if (!this.name || !this.email || !this.password || !this.confirmPassword || !this.phoneno) {
      alert('All fields are required!');
      return;
    }

    if (this.password !== this.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    

    // Show loading indicator
    this.loading = true;

    const userPayload = {
      name: this.name,
      email: this.email,
      password: this.password,
      phoneno: this.phoneno,
    };

    this.http.post(
      'http://localhost:3000/user/create',
      userPayload
    ).subscribe(
      (resultData) => {
        this.loading = false;
        if (resultData) {
          alert('Registration successful!');
          this.router.navigate(['/login']);
        } else {
          alert('Registration failed. Please try again!');
        }
      },
      (error) => {
        this.loading = false;
        console.error('Error:', error); 
        alert('An error occurred: ' + error.message);
      }
    );
  }
}
