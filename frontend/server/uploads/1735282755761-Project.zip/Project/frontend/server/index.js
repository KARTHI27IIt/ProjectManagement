const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");
const routes = require("./routes/routes");
const Nodemailer = require("nodemailer");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const { userSchemaModel, employeeSchemaModel } = require("./userController/userModel");

app.use(routes);

mongoose.connect("mongodb://localhost:27017/", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("MongoDB connected");
  })
  .catch((err) => {
    console.log("error:", err);
  });

app.get('/api/admin/details', async (req, res) => {
  const { email } = req.query;

  try {
    const admin = await userSchemaModel.find({ email, role: 'admin' });

    if (!admin) {
      return res.status(404).json({ status: false, message: 'Admin not found.' });
    }

    res.status(200).json({ status: true, adminDetails: admin });
  } catch (error) {
    console.error('Error fetching admin details:', error);
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/employee/details', async (req, res) => {
  const { email } = req.query;

  try {
    const employee = await employeeSchemaModel.find({ empEmail: email });

    if (!employee) {
      return res.status(404).json({ status: false, message: 'Employee not found.' });
    }

    res.status(200).json({ status: true, employeeDetails: employee });
  } catch (error) {
    console.error('Error fetching employee details:', error);
    res.status(500).json({ status: false, message: error.message });
  }
});


const GMAIL_USER = "karthikeyan2.0doc@gmail.com"; 
const GMAIL_PASS = "whme cwrl cyih fmtn"; 
const { MailtrapTransport } = require("mailtrap");
const TOKEN = "efe19273f8f97fd2c9c612e3f7f19b37";
const fs =require("fs");
const path=require("path");
app.post("/user/sendEmail", async (req, res) => {
  // const transport = Nodemailer.createTransport({
  //   service: "gmail",
  //   auth: {
  //     user: GMAIL_USER,
  //     pass: GMAIL_PASS,
  //   },
  // });


    const transport = Nodemailer.createTransport(
    MailtrapTransport({
      token: TOKEN,
      testInboxId: 3341042,
    })
  );
  
  const emailContent = `
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(95, 224, 218);
            margin: 0;
            padding: 0;
            color: #333333;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow:10px 10px 20px black'
            overflow: hidden;
        }
        .email-header {
            background-image: linear-gradient(135deg, #56CCF2, #031cff);
            color: #ffffff;
            text-align: center;
            padding: 20px;
        }
        .email-header h1 {
            margin: 0;
            font-size: 24px;
        }
        .email-body {
            padding: 20px;
        }
        .email-body h2 {
            color:rgb(38, 174, 219);
            margin-top: 0;
        }
        .email-body p {
            margin: 10px 0;
        }
        .task-table {
            width: 100%;
           
            margin-top: 20px;
        }
        .task-table th, .task-table td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        .task-table th {
            background-color: #f2f2f2;
        }
        
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <h1>${req.body.report_type} Notification</h1>
        </div>
        <div class="email-body">
            <h2>Project Details</h2>
            <table class="task-table">
                <tr>
                    <th>Project ID</th>
                    <td>${req.body.project_id}</td>
                </tr>
                <tr>
                    <th>Task Name</th>
                    <td>${req.body.task_name}</td>
                </tr>
                <tr>
                    <th>Report Type</th>
                    <td>${req.body.report_type}</td>
                </tr>
                <tr>
                    <th>Report Description</th>
                    <td>${req.body.report_desc}</td>
                </tr>
                <tr>
                    <th>Employee Name</th>
                    <td>${req.body.empName}</td>
                </tr>
                <tr>
                    <th>Employee Email</th>
                    <td>${req.body.empEmail}</td>
                </tr>
                <tr>
                    <th>Task Status</th>
                    <td>${req.body.task_status}</td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
`

console.log(req.body.attachments);
  try {
    await transport.sendMail({
      from: { address: GMAIL_USER, name: req.body.empName },
      to: ["real-email@example.com"], 
      subject: req.body.report_type || "Report Submission", 
      html: emailContent,
      // attachments:{
      //   filename:"email.jpg",
      //   path:req.body.attachments,
      //   cid:"email.jpg"
      // },
      category: "Integration Test",
      sandbox: true
    });

    res.status(200).json({ status: true, message: "Mail sent successfully" });
  } catch (error) {
    console.error("Error sending mail:", error);
    res.status(500).json({ status: false, message: "Mail sending failed." });
  }
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});



// const multer = require("multer");


// const upload = multer({ dest: 'uploads/' });  

// const GMAIL_USER = "karthikeyan2.0doc@gmail.com";
// const GMAIL_PASS = "whme cwrl cyih fmtn";
// const { MailtrapTransport } = require("mailtrap");
// const TOKEN = "efe19273f8f97fd2c9c612e3f7f19b37";

// app.post("/user/sendEmail", async (req, res) => {
//   const transport = Nodemailer.createTransport(
//     MailtrapTransport({
//       token: TOKEN,
//       testInboxId: 3341042,
//     })
//   );

//   // Assuming the image is being uploaded as a file and sent to the server
//   const imageAttachment = req.files ? req.files.image : null; // Replace 'image' with the correct field name

//   if (!imageAttachment) {
//     return res.status(400).json({ status: false, message: "No image file uploaded." });
//   }

//   let emailContent = `
//     <!DOCTYPE html>
//     <html>
//     <head>
//         <style>
//             body {
//                 font-family: Arial, sans-serif;
//                 background-color: rgb(95, 224, 218);
//                 margin: 0;
//                 padding: 0;
//                 color: #333333;
//             }
//             .email-container {
//                 max-width: 600px;
//                 margin: 20px auto;
//                 background: #ffffff;
//                 border-radius: 8px;
//                 box-shadow:10px 10px 20px black;
//                 overflow: hidden;
//             }
//             .email-header {
//                 background-image: linear-gradient(135deg, #56CCF2, #031cff);
//                 color: #ffffff;
//                 text-align: center;
//                 padding: 20px;
//             }
//             .email-header h1 {
//                 margin: 0;
//                 font-size: 24px;
//             }
//             .email-body {
//                 padding: 20px;
//             }
//             .email-body h2 {
//                 color:rgb(38, 174, 219);
//                 margin-top: 0;
//                 text-shadow:2px 2px 4px black;
//             }
//             .email-body p {
//                 margin: 10px 0;
//             }
//             .task-table {
//                 width: 100%;
//                 margin-top: 20px;
//             }
//             .task-table th, .task-table td {
//                 border: 1px solid #dddddd;
//                 text-align: left;
//                 padding: 8px;
//             }
//             .task-table th {
//                 background-color: #f2f2f2;
//             }
//         </style>
//     </head>
//     <body>
//         <div class="email-container">
//             <div class="email-header">
//                 <h1>${req.body.report_type} Notification</h1>
//             </div>
//             <div class="email-body">
//                 <h2>Project Details</h2>
//                 <table class="task-table">
//                     <tr>
//                         <th>Project ID</th>
//                         <td>${req.body.project_id}</td>
//                     </tr>
//                     <tr>
//                         <th>Task Name</th>
//                         <td>${req.body.task_name}</td>
//                     </tr>
//                     <tr>
//                         <th>Report Type</th>
//                         <td>${req.body.report_type}</td>
//                     </tr>
//                     <tr>
//                         <th>Report Description</th>
//                         <td>${req.body.report_desc}</td>
//                     </tr>
//                     <tr>
//                         <th>Employee Name</th>
//                         <td>${req.body.empName}</td>
//                     </tr>
//                     <tr>
//                         <th>Employee Email</th>
//                         <td>${req.body.empEmail}</td>
//                     </tr>
//                     <tr>
//                         <th>Task Status</th>
//                         <td>${req.body.task_status}</td>
//                     </tr>
//                 </table>
                
//                 <!-- Display image using cid -->
//                 <img src="cid:projectImage" alt="Project Image" style="max-width: 100%; height: auto;" />
//             </div>
//         </div>
//     </body>
//     </html>
//   `;

//   try {
//     const mailOptions = {
//       from: { address: GMAIL_USER, name: req.body.empName },
//       to: GMAIL_USER, 
//       subject: req.body.report_type || "Report Submission",
//       html: emailContent,
//       attachments: [
//         {
//           filename: imageAttachment.name, // Image file name
//           path: imageAttachment.tempFilePath, // Path to the uploaded file
//           cid: 'projectImage', // Content-ID to reference in the email body
//         }
//       ],
//       category: "Integration Test",
//       sandbox: true,
//     };

//     await transport.sendMail(mailOptions);

//     res.status(200).json({ status: true, message: "Mail sent successfully" });
//   } catch (error) {
//     console.error("Error sending mail:", error);
//     res.status(500).json({ status: false, message: "Mail sending failed." });
//   }
// });





